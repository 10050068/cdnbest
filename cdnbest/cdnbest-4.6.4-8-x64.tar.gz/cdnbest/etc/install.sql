CREATE TABLE `vhost_info` (
	[vhost] varchar(32) NOT NULL,	
	[name] varchar(64) NOT NULL,
	[type] tinyint(4) NOT NULL DEFAULT 0,
	[value] varchar(255) DEFAULT NULL, 
	[id] INTEGER NOT NULL DEFAULT 1000
);
CREATE INDEX [IDX_VHOST_INFO_VHOST_TYPE_ID] ON [vhost_info](
	[vhost],[type],[id]
);
CREATE TABLE `setting` (
	[name] VARCHAR(255) NULL PRIMARY KEY,
	[value] text NULL
);
CREATE TABLE [domain] (
	[vhost] VARCHAR(255) NOT NULL,
	[id] INTEGER NOT NULL,
	[domain] VARCHAR(255) NOT NULL,
	[value] VARCHAR(255) NOT NULL,
	[t] INTEGER DEFAULT 0 NULL,
	[status] INTEGER DEFAULT 0 NULL,
	[public_setting] TEXT NULL,
	[private_setting] TEXT NULL,
	PRIMARY KEY ([vhost],[id])
);
CREATE TABLE [vhost] (
	[name] VARCHAR(255) PRIMARY KEY NULL,
	[doc_root] VARCHAR(255) NULL,
	[uid] VARCHAR(255) DEFAULT 1000 NOT NULL,
	[gid] VARCHAR(255) DEFAULT 1100 NOT NULL,
	[status] INTEGER DEFAULT 0 NULL,
	[htaccess] VARCHAR(255) NULL,
	[access] VARCHAR(255) NULL,
	[max_connect] INTEGER DEFAULT 0 NULL,
	[speed_limit] INTEGER DEFAULT 0 NULL,
	[max_worker] INTEGER DEFAULT 0 NULL,
	[max_queue] INTEGER DEFAULT 0 NULL,
	[log_file] VARCHAR(255) NULL,
	[flow] INTEGER DEFAULT 0 NOT NULL,
	[hcount] INTEGER DEFAULT 0 NOT NULL,
	[cs] INTEGER DEFAULT 0 NOT NULL,
	[envs] VARCHAR(255) DEFAULT NULL NULL,
	[log_handle] INTEGER DEFAULT 0 NULL,
	[flow_limit] INTEGER DEFAULT 0 NOT NULL,
	[certificate] TEXT NULL,
	[certificate_key] TEXT NULL,
	[cipher] VARCHAR(255) DEFAULT NULL NULL,
	[protocols] VARCHAR(255) DEFAULT NULL NULL,
	[fflow] INTEGER DEFAULT 1 NOT NULL,
	[http2] INTEGER DEFAULT 0 NOT NULL,
	[pgid_four] INTEGER DEFAULT -1 NOT NULL,
	[log_rotate_time] VARCHAR(255) DEFAULT "0 */1 * * *",
	[node_router] VARCHAR(255) DEFAULT NULL NULL,
	[early_data] INTEGER DEFAULT 0
);
CREATE TABLE `vhost_config` (
	[vhost] VARCHAR(255) NOT NULL,
	[name] VARCHAR(255) NULL,
	[id] INTEGER DEFAULT 0 NULL,
	[value] TEXT NULL,
	PRIMARY KEY ([vhost],[name],[id])
);
CREATE TABLE `router_config` (
	[id] INTEGER  NOT NULL ,
	[indexd] INTEGER DEFAULT 0 NOT NULL ,
	[dst_ip] VARCHAR(255) NOT NULL,
	[gateway] TEXT DEFAULT 0 NOT NULL,
	[hash] INTEGER  DEFAULT 0 NOT NULL,
	PRIMARY KEY ([indexd],[id])
);
CREATE TABLE `port` (
        [id] INTEGER  NOT NULL ,
        [ip] VARCHAR(255) NOT NULL,
        [vhost] VARCHAR(255) NOT NULL,
        [port] INTEGER NOT NULL,
        PRIMARY KEY ([vhost],[id])
);
CREATE TABLE `product_node` (
        [pgid] INTEGER NOT NULL,
        [id] INTEGER  NOT NULL , 
        [master_id] INTEGER  NOT NULL ,      
        [monitor_ip] VARCHAR(255) NOT NULL,
        PRIMARY KEY ([pgid],[id])
);
CREATE TABLE `black_list` (
	[ip] VARCHAR(255) PRIMARY KEY NOT NULL,
	[flags] INTEGER NOT NULL
);
CREATE TABLE `vhost_port` (
        [vhost] VARCHAR(255) NOT NULL,
        [port] INTEGER NOT NULL,
        [id] INTEGER NOT NULL,
        [type] INTEGER  NOT NULL ,
        [host] VARCHAR(255) NOT NULL,
        [public_setting] VARCHAR(255) NOT NULL DEFAULT '',
        [private_setting] VARCHAR(255) NOT NULL DEFAULT '',
        PRIMARY KEY ([vhost],[id])
);
CREATE TABLE `preload_url_task` (
        [id] INTEGER UNIQUE NOT NULL,
        [success_num] INTEGER DEFAULT 0 NOT NULL,
        [fail_num] INTEGER DEFAULT 0 NOT NULL,
        [start_time] datetime NOT NULL,
        [end_time] datetime  NULL,
        [status] INTEGER DEFAULT 0 NOT NULL,
        [success_indexs] varchar(255) DEFAULT "" NOT NULL
);
