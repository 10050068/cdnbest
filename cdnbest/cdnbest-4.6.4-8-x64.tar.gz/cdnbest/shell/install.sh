#!/bin/sh
BIN_FILE=$(readlink -f $0)
WORK_DIR=$(dirname $(dirname $BIN_FILE))
. $WORK_DIR/shell/common.sh
if [ $# != 1 ] ;then
        echo "usage: install.sh uid"
        exit 1
fi
CB_UID=$1
DEST_DIR=/vhs
cd /tmp
disable_selinux
stop_system
install_depends
install_project
install_kangle
setup_kangle
service kangle start
service cdnbest start
